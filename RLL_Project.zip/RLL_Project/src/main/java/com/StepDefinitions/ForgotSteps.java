package com.StepDefinitions;
import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;
import com.pages.ForgotPage;
import com.pages.HomePage; 
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When; 
public class ForgotSteps { 

	WebDriver driver;	 
	ForgotPage fp; 
	HomePage hp; 
	Logger log3; 

	@Before 

	public void init() { 

		driver = new ChromeDriver(); 
		fp = new ForgotPage(driver); 
		hp = new HomePage(driver); 
		log3 = Logger.getLogger(ForgotPage.class); 

	} 



	@Given("user should be on the forgot password page") 

	public void user_should_be_on_forgot_password_page() { 

		// Add code to navigate to the forgot password page 

		hp.launch(); 

		hp.clickMyAccount(); 
		log3.info("user is in forgot page");

	} 



	@When("^user enters (.*)$") 

	public void user_enters_forgotmoboremail(String fotgotmoboremail) { 

		fp.enterForgotMobileEmail(fotgotmoboremail); 

	} 



	@When("user clicks on continue") 

	public void user_clicks_on_continue() { 

		fp.clickContinueButton(); 

	} 
	
	@Then ("user should see a status message indicating status")
	public void user_should_see_a_status_message_indicating_status() {
		
	}



} 



