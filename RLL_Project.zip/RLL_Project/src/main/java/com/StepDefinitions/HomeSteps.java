package com.StepDefinitions;

import java.util.NoSuchElementException;

//import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
//import org.openqa.selenium.By;
//import org.apache.commons.logging.Log; 
//import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pages.HomePage;
//import org.testng.Assert;

//import dev.failsafe.internal.util.Assert;
//import org.junit.Assert;
//import com.sun.tools.javac.util.Assert;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 
public class HomeSteps { 
	WebDriver driver;	 
	HomePage hp; 
	Logger log;

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 

		hp = new HomePage(driver); 

		log = Logger.getLogger(HomePage.class);
	} 



	@Given ("user should be in home page1") 

	public void user_should_be_in_home_page1() { 

		hp.launch(); 

		log.info("Browser is launched"); 
	} 

	@When ("user click on my account") 

	public void user_click_on_my_account() { 

		hp.clickMyAccount(); 

		log.info("Clicked on my account"); 

	} 

	@Then ("user should be navigated to the My Account page2") 

	public void user_should_be_navigated_to_the_My_Account_page2() { 
				String expectedUrl = "https://www.bookswagon.com/my-account"; // Replace with the actual My Account page URL
				String currentUrl = driver.getCurrentUrl();
		
		//		// Assert that the current URL matches the expected URL
			Assert.assertEquals("User is not navigated to the My Account page.", expectedUrl, currentUrl);

		// Optionally, assert that a specific element on the My Account page is displayed
				try {
					WebElement accountHeading = driver.findElement(By.xpath("//h1[text()='My Account']")); // Replace with actual locator
					Assert.assertTrue(accountHeading.isDisplayed(),"My Account heading is not displayed.");
				} catch (NoSuchElementException e) {
					Assert.fail("My Account heading element is not found.");
				}
	} 
}


