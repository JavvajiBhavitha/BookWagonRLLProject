//package com.pages;
//import org.openqa.selenium.By; 
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait; 
//import java.time.Duration;
//
//public class ForgotPage { 
//
//	WebDriver driver; 
//
//	By forgotMobileEmailField = By.name("ctl00$phBody$ForgotPassword$txtFGEmail"); 
//	By continueButton = By.id("ctl00_phBody_ForgotPassword_lnkForgotPassword"); 
//
//	public ForgotPage(WebDriver driver) { 
//
//		this.driver = driver; 
//
//	} 
//
//	public void launch() { 
//
//		driver.get("https://www.bookswagon.com/"); 
//
//	} 
//
//	public void enterForgotMobileEmail(String fotgotmoboremail) { 
//		
//		WebDriverWait wait = new WebDriverWait(driver, 10); // wait for 10 seconds
//	    wait.until(ExpectedConditions.elementToBeClickable(forgotMobileEmailField));
//
//		driver.findElement(forgotMobileEmailField).sendKeys(fotgotmoboremail); 
//
//	} 
//
//	public void clickContinueButton() { 
//
//		driver.findElement(continueButton).click(); 
//
//	} 
//
//
//} 
//
//
package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait; 
import java.time.Duration;

public class ForgotPage {
    WebDriver driver; 

    By forgotMobileEmailField = By.name("ctl00$phBody$ForgotPassword$txtFGEmail"); 
    By continueButton = By.id("ctl00_phBody_ForgotPassword_lnkForgotPassword"); 

    public ForgotPage(WebDriver driver) { 
        this.driver = driver; 
    } 

    public void enterForgotMobileEmail(String fotgotmoboremail) { 
        // Create a WebDriverWait instance with Duration
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // wait for 10 seconds
        wait.until(ExpectedConditions.visibilityOfElementLocated(forgotMobileEmailField));

        wait.until(ExpectedConditions.elementToBeClickable(forgotMobileEmailField));

        //driver.findElement(forgotMobileEmailField).sendKeys(fotgotmoboremail); 
        WebElement element = driver.findElement(forgotMobileEmailField);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        element.sendKeys(fotgotmoboremail);
    } 

    public void clickContinueButton() { 
        driver.findElement(continueButton).click(); 
    } 
}
