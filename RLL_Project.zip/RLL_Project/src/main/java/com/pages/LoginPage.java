package com.pages;

import java.time.Duration;

//import java.time.Duration; 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait; 
//import org.openqa.selenium.support.ui.ExpectedConditions; 
//import org.openqa.selenium.support.ui.WebDriverWait; 

public class LoginPage { 



	WebDriver driver; 

	By mobileEmailField = By.id("ctl00_phBody_SignIn_txtEmail"); 

	By passwordField = By.id("ctl00_phBody_SignIn_txtPassword"); 

	By loginButton = By.id("ctl00_phBody_SignIn_btnLogin"); 



	By forgotPasswordLink = By.xpath("//a[contains(text(),'Forgot your Password?')]"); 
	

	By fgotpassword = By.xpath("//input[@name=\"ctl00$phBody$ForgotPassword$txtFGPassword\"]"); 

	By fgotconfmpassword = By.id("ctl00_phBody_ForgotPassword_txtConfirmFGPwd"); 

	By fgotloginbutton = By.name("ctl00$phBody$ForgotPassword$btnFGLogin"); 

	

	By reqotp = By.id("ctl00_phBody_SignIn_btnRequestOTP"); 

	By entreqotp = By.name("ctl00$phBody$SignIn$txtEnterOTP"); 

	By verify = By.name("ctl00$phBody$SignIn$btnOTP");

	

	public LoginPage(WebDriver driver) { 

		this.driver = driver; 

	} 



	public void launch(WebDriver driver) { 

		driver.get("https://www.bookswagon.com/"); 

	} 


	public void enter_mobemail(String mobileoremail) { 

		driver.findElement(mobileEmailField).sendKeys(mobileoremail); 

	} 

	public void enter_password(String password) { 

		driver.findElement(passwordField).sendKeys(password); 

	} 

	public void Click_Login() { 

		driver.findElement(loginButton).click(); 

	} 





	public void ForgotPwdLink()  { 

		driver.findElement(forgotPasswordLink).click();		 

	} 
	
	

	public void Enter_Forgotpwd(String forgotpassword) { 

		driver.findElement(fgotpassword).sendKeys(forgotpassword); 

	} 

	public void Enter_ConfmForgotPwd(String forgotconfmpassword) { 

		driver.findElement(fgotconfmpassword).sendKeys(forgotconfmpassword); 

	} 

	public void Forgot_LoginButton() { 

		driver.findElement(fgotloginbutton).click(); 

	} 

	public void ReqOtp() { 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reqotp));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    element.click();
		driver.findElement(reqotp).click(); 

	} 

	public void Enter_ReqOtp(String otp1) throws InterruptedException { 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.visibilityOfElementLocated(entreqotp)).sendKeys(otp1);
	    Thread.sleep(2000);

		driver.findElement(entreqotp).sendKeys(otp1); 

//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15)); 
//
//		wait.until(ExpectedConditions.elementToBeClickable(reqotp)); 
		//Thread.sleep(15000);



	} 

	public void Verify() { 

		driver.findElement(verify).click();

	} 
}






