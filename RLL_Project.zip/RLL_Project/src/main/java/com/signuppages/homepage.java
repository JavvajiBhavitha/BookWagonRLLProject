package com.signuppages;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 

public class homepage { 

	WebDriver driver; 
	By myAccount = By.id("ctl00_lblUser"); 
	public homepage(WebDriver driver) { 

		this.driver = driver; 

	} 
	public void launch() { 
		driver.get("https://www.bookswagon.com/"); 
	} 
	public void clickMyAccount() { 
		driver.findElement(myAccount).click(); 
	} 
} 



