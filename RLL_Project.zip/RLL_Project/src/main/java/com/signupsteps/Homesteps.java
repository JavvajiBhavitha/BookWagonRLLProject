package com.signupsteps;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.pages.HomePage;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 
public class Homesteps { 
	WebDriver driver;	 
	HomePage hp; 
	Logger log;

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 

		hp = new HomePage(driver); 

		log = Logger.getLogger(HomePage.class);
	} 
	@Given ("user should be in home page1") 

	public void user_should_be_in_home_page1() { 

		hp.launch(); 

		log.info("Browser is launched"); 
	} 

	@When ("user click on my account") 

	public void user_click_on_my_account() { 

		hp.clickMyAccount(); 

		log.info("Clicked on my account"); 

	} 

	@Then ("user should be navigated to the My Account page3") 

	public void user_should_be_navigated_to_the_My_Account_page3() { 
		
	} 
}



