package com.signupsteps;


import com.pages.HomePage;
import com.signuppages.Loginpage;
import com.signuppages.Signuppage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;

//import static org.junit.Assert.assertTrue;

public class Loginsteps {
    WebDriver driver;
    Loginpage loginPage;
    HomePage hp;
    Signuppage signuppage;


    @Given("user should be in login page")
    public void user_should_be_in_login_page() {
        // Initialize the WebDriver (for example, using ChromeDriver)
        //System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://www.bookswagon.com/login"); // Replace with your actual login page URL

        // Initialize the Loginpage object
        loginPage = new Loginpage(driver);
        hp = new HomePage(driver);
        signuppage = new Signuppage(driver);
    }

    @When("user clicks on sign up link")
    public void user_clicks_on_sign_up_link() {
        loginPage.clickSignUpLink();
    }

    @When("user enter otp")
    public void user_enter_otp() {
        // Assuming you have a method to retrieve the OTP for testing
        String otp = "YOUR_OTP"; // Replace with actual OTP logic
        loginPage.enterOtp(otp);
    }
    @When("^user enter password (.*)$")
    public void user_enter_password(String pwd) throws InterruptedException {
        loginPage.enterPassword(pwd);
    }

    @When("^user enter confirm password  (.*)$")
    public void user_enter_confirm_password(String confirmpwd) throws InterruptedException {
        loginPage.enterConfirmPassword(confirmpwd);
    }

    @When("user clicks on signup button")
    public void user_clicks_on_signup_button() throws InterruptedException {
        loginPage.clickSignUpButton();
    }

    @Then("user should register successfully")
    public void user_should_register_successfully() {
        // You should implement a proper way to check registration success
        // For example, checking for a success message or redirection
//        WebDriverWait wait = new WebDriverWait(driver, 10);
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("SUCCESS_MESSAGE_ID"))); // Replace with actual success message element ID
//
//        // Assert that the success message is displayed
//        assertTrue(driver.findElement(By.id("SUCCESS_MESSAGE_ID")).isDisplayed());
//
//        // Close the browser
//        driver.quit();
    }

    // Cleanup method to ensure the driver is closed after each scenario
    @io.cucumber.java.After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
