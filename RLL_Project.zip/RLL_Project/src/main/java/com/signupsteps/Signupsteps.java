package com.signupsteps;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.HomePage;
import com.signuppages.Loginpage;
import com.signuppages.Signuppage;

//import static org.junit.Assert.assertTrue;

public class Signupsteps {
    WebDriver driver;
    Loginpage loginPage;
    Signuppage signuppage;
    HomePage hp; 

    @Given("the user is on the sign-up page")
    public void userIsOnSignUpPage() {
        // Set up the WebDriver (make sure to set the path to your WebDriver executable)
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://www.bookswagon.com/login#"); // Replace with your actual signup page URL

        // Initialize the Signuppage object
        signuppage = new Signuppage(driver);
        hp = new HomePage(driver);
        loginPage = new Loginpage(driver);
    }
    @When("^the user enters their name (.*)$")
    public void userEntersName(String name) throws InterruptedException {
        signuppage.enterName(name);
    }

    @When("^the user enters their mobile number (.*)$")
    public void userEntersMobileNumber(String phno) throws InterruptedException {
        signuppage.enterMobileNumber(phno);
    }

    @When("the user clicks the continue button")
    public void userClicksContinueButton() throws InterruptedException {
        signuppage.clickContinueButton();
    }

    @Then("the user should be taken to the next step")
    public void userShouldBeTakenToNextStep() {
        // Here, add assertions to verify the next step is correct
        // This can be checking for a URL change, visibility of an element, etc.
//        String currentUrl = driver.getCurrentUrl();
//        assertTrue(currentUrl.contains("EXPECTED_PART_OF_NEXT_URL")); // Adjust accordingly
    }

    @Then("the user closes the browser")
    public void userClosesBrowser() {
        driver.quit();
    }
}
