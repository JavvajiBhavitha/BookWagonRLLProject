package com.DryRun;

import org.openqa.selenium.WebDriver; 

import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.ForgotPage;
import com.pages.HomePage;
import com.pages.LoginPage; 
public class DryRun { 
public static void main(String[] args) throws InterruptedException { 

WebDriver driver; 

driver = new ChromeDriver(); 


HomePage hp = new HomePage(driver); 
LoginPage lp = new LoginPage(driver); 
ForgotPage fp = new ForgotPage(driver); 


hp.launch(); 

hp.clickMyAccount(); 

lp.enter_mobemail("9603249505"); 



lp.enter_password("Bhavi@11"); 

lp.Click_Login();

 



lp.ForgotPwdLink(); 

fp.enterForgotMobileEmail("7731960046");

fp.clickContinueButton();

Thread.sleep(15000); 

lp.Enter_Forgotpwd("Harsha@12"); 

lp.Enter_ConfmForgotPwd("Harsha@12"); 

lp.Forgot_LoginButton(); 



 

lp.ReqOtp(); 

lp.Enter_ReqOtp(""); 

lp.Verify(); 

 

 

 

 

 

 

 

/* 

 

HomePage hp = new HomePage(driver); 

Login_Page lp = new Login_Page(driver); 

hp.launch(); 

 

hp.Click_MyAccount(); 

lp.enter_mobemail("7731960046"); 

}*/ 

 

} 

} 
