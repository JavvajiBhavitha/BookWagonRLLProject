package com.TestNGRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests; 

import io.cucumber.testng.CucumberOptions; 

@CucumberOptions(features = "src/test/java/com/features", 

glue = "com.StepDefinitions", 

plugin = {"pretty", "html:target/cucumber-reports.html"}, 

tags = "@homepage or @forgot or @login", 

monochrome = true 

		) 
public class Runner extends AbstractTestNGCucumberTests{ 



} 