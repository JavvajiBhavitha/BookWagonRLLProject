package com.signuprunner;
import io.cucumber.testng.AbstractTestNGCucumberTests; 

import io.cucumber.testng.CucumberOptions; 

@CucumberOptions(features = "src/test/java/com/signupfeatures", 

glue = "com.signupsteps", 

plugin = {"pretty", "html:target/cucumber-reports.html"}, 

tags = "@home or @signup1 or  @login1", 

monochrome = true 

		) 
public class TestngsignupRunner extends AbstractTestNGCucumberTests{ 



} 